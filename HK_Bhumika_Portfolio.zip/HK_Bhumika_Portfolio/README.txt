H K BHUMIKA — PORTFOLIO WEBSITE

FILES
- index.html: portfolio content and page structure
- style.css: responsive design and styling
- script.js: mobile navigation menu
- resume.pdf: resume supplied for this portfolio

HOW TO OPEN
1. Extract the ZIP file.
2. Keep all files in the same folder.
3. Double-click index.html to open it in Chrome, Edge, or Firefox.
4. Internet access is needed to load the Google Fonts; the site otherwise works locally.

BEFORE PUBLISHING
- Check the phone number, email, LinkedIn, and GitHub links.
- The portfolio uses the details supplied in your resume.
- If you publish the site online, use a reputable static hosting service and test every link.
